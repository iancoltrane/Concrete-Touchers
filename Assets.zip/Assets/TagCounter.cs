using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TagCounter : MonoBehaviour
{
    public Text counterText;
    int tags;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        ShowTags();
    }

    private void ShowTags()
    {
        counterText.text = tags.ToString();
    }

    private void Addtag()
    {
        tags++;
    }
}
